import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle2, Clock } from "lucide-react";
import { format } from "date-fns";

export default function ReadReceiptModal({ message, open, onClose, participants = [] }) {
  const readBy = message?.read_by || [];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Read Receipts</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 mt-2">
          {participants.map((email) => {
            const receipt = readBy.find(r => r.email === email);
            return (
              <div key={email} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <span className="text-sm text-gray-800">{email}</span>
                {receipt ? (
                  <div className="flex items-center gap-1 text-green-600 text-xs">
                    <CheckCircle2 className="w-3 h-3" />
                    {receipt.read_at && format(new Date(receipt.read_at), 'MMM d, h:mm a')}
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-gray-400 text-xs">
                    <Clock className="w-3 h-3" /> Not read
                  </div>
                )}
              </div>
            );
          })}
          {participants.length === 0 && (
            <p className="text-sm text-gray-500 text-center py-4">No participants</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}