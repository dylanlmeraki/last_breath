import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Reply, Eye, ChevronDown, ChevronRight } from "lucide-react";
import { format } from "date-fns";

export default function ThreadedMessageView({ message, replies, currentUser, onReply, allMessages, onShowReadReceipts }) {
  const [showReplies, setShowReplies] = useState(true);

  const directReplies = (allMessages || []).filter(m => m.parent_message_id === message.id);
  const isOwn = message.sender_email === currentUser?.email;
  const readBy = message.read_by || [];

  return (
    <div className={`space-y-2 ${message.thread_depth > 0 ? 'ml-6 border-l-2 border-blue-100 pl-4' : ''}`}>
      <div className={`p-4 rounded-lg ${isOwn ? 'bg-blue-50 border border-blue-200' : 'bg-white border border-gray-200'}`}>
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${isOwn ? 'bg-blue-600' : 'bg-gray-500'}`}>
              {(message.sender_name || 'U').charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900">{message.sender_name}</p>
              <p className="text-xs text-gray-500">
                {message.created_date && format(new Date(message.created_date), 'MMM d, h:mm a')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {message.urgency === 'urgent' && <Badge className="bg-red-100 text-red-700 text-xs">Urgent</Badge>}
            {message.urgency === 'high' && <Badge className="bg-orange-100 text-orange-700 text-xs">High</Badge>}
          </div>
        </div>

        <p className="text-sm text-gray-800 whitespace-pre-wrap">{message.message}</p>

        {message.attachments?.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {message.attachments.map((att, idx) => (
              <a key={idx} href={att.file_url || att} target="_blank" rel="noopener noreferrer"
                className="text-xs text-blue-600 underline hover:text-blue-800">
                {att.file_name || `Attachment ${idx + 1}`}
              </a>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3 mt-3 pt-2 border-t border-gray-100">
          <Button size="sm" variant="ghost" className="h-6 text-xs text-gray-500" onClick={() => onReply?.(message)}>
            <Reply className="w-3 h-3 mr-1" /> Reply
          </Button>
          <Button size="sm" variant="ghost" className="h-6 text-xs text-gray-500" onClick={() => onShowReadReceipts?.(message)}>
            <Eye className="w-3 h-3 mr-1" /> {readBy.length} read
          </Button>
          {directReplies.length > 0 && (
            <Button size="sm" variant="ghost" className="h-6 text-xs text-gray-500" onClick={() => setShowReplies(!showReplies)}>
              {showReplies ? <ChevronDown className="w-3 h-3 mr-1" /> : <ChevronRight className="w-3 h-3 mr-1" />}
              {directReplies.length} {directReplies.length === 1 ? 'reply' : 'replies'}
            </Button>
          )}
        </div>
      </div>

      {showReplies && directReplies.map(reply => (
        <ThreadedMessageView
          key={reply.id}
          message={reply}
          replies={replies}
          currentUser={currentUser}
          onReply={onReply}
          allMessages={allMessages}
          onShowReadReceipts={onShowReadReceipts}
        />
      ))}
    </div>
  );
}