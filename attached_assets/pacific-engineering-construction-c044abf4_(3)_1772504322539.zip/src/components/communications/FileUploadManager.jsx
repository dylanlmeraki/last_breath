import React, { useState } from "react";
import { portalApi } from "@/components/services/portalApi";
import { Button } from "@/components/ui/button";
import { Paperclip, X, Loader2 } from "lucide-react";

export default function FileUploadManager({ onFilesUploaded, maxFiles = 10 }) {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e) => {
    const selected = Array.from(e.target.files);
    if (files.length + selected.length > maxFiles) return;

    setUploading(true);
    const uploaded = [];

    for (const file of selected) {
      const { file_url } = await portalApi.integrations.Core.UploadFile({ file });
      uploaded.push({
        file_name: file.name,
        file_url,
        file_size: file.size,
        file_type: file.type,
      });
    }

    const newFiles = [...files, ...uploaded];
    setFiles(newFiles);
    onFilesUploaded?.(newFiles);
    setUploading(false);
  };

  const removeFile = (idx) => {
    const newFiles = files.filter((_, i) => i !== idx);
    setFiles(newFiles);
    onFilesUploaded?.(newFiles);
  };

  return (
    <div>
      {files.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {files.map((f, idx) => (
            <div key={idx} className="flex items-center gap-1 bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded">
              <span className="truncate max-w-[120px]">{f.file_name}</span>
              <button onClick={() => removeFile(idx)} className="hover:text-red-500"><X className="w-3 h-3" /></button>
            </div>
          ))}
        </div>
      )}
      <label className="inline-flex items-center gap-1 text-xs text-gray-500 cursor-pointer hover:text-blue-600">
        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
        <span>{uploading ? 'Uploading...' : 'Attach files'}</span>
        <input type="file" multiple className="hidden" onChange={handleFileChange} disabled={uploading} />
      </label>
    </div>
  );
}