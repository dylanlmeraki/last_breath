import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, FileText, ListChecks } from "lucide-react";

export default function TemplatePreviewPanel({ template, onSelect, isSelected }) {
  if (!template) {
    return (
      <Card className="p-8 border-0 shadow-sm bg-gray-50 text-center">
        <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-sm text-gray-500">Select a template to preview its details</p>
      </Card>
    );
  }

  const milestones = template.default_milestones || [];
  const tasks = template.default_tasks || [];

  return (
    <Card className={`p-6 border-2 shadow-sm ${isSelected ? 'border-blue-500 bg-blue-50/30' : 'border-gray-200'}`}>
      <div className="space-y-4">
        <div>
          <h4 className="text-lg font-bold text-gray-900">{template.template_name}</h4>
          <p className="text-sm text-gray-600 mt-1">{template.description || 'No description'}</p>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline">{template.project_type}</Badge>
            {template.default_priority && <Badge variant="outline">{template.default_priority}</Badge>}
          </div>
        </div>

        {milestones.length > 0 && (
          <div>
            <h5 className="text-sm font-semibold text-gray-800 flex items-center gap-1 mb-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600" /> Milestones ({milestones.length})
            </h5>
            <div className="space-y-1">
              {milestones.map((m, idx) => (
                <div key={idx} className="text-xs text-gray-700 bg-white p-2 rounded border border-gray-100">
                  {m.milestone_name}
                  {m.days_from_start != null && <span className="text-gray-400 ml-2">Day {m.days_from_start}</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        {tasks.length > 0 && (
          <div>
            <h5 className="text-sm font-semibold text-gray-800 flex items-center gap-1 mb-2">
              <ListChecks className="w-4 h-4 text-green-600" /> Tasks ({tasks.length})
            </h5>
            <div className="space-y-1">
              {tasks.map((t, idx) => (
                <div key={idx} className="text-xs text-gray-700 bg-white p-2 rounded border border-gray-100">
                  {t.task_name}
                  {t.duration_days && <span className="text-gray-400 ml-2">{t.duration_days}d</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}