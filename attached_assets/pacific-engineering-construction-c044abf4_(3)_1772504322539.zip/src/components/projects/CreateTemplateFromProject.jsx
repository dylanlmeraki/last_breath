import React, { useState } from "react";
import { portalApi } from "@/components/services/portalApi";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function CreateTemplateFromProject({ open, onOpenChange, projects = [], user }) {
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [description, setDescription] = useState("");
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: async () => {
      const project = projects.find(p => p.id === selectedProjectId);
      if (!project) throw new Error("Project not found");

      return portalApi.entities.ProjectTemplate.create({
        template_name: templateName,
        description,
        project_type: project.project_type,
        source_project_id: project.id,
        is_active: true,
        created_by_email: user?.email,
        default_priority: project.priority || "Medium",
        default_milestones: [],
        default_tasks: [],
        usage_count: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["project-templates"] });
      toast.success("Template created from project");
      onOpenChange(false);
      setTemplateName("");
      setDescription("");
      setSelectedProjectId("");
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Template from Project</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
            <SelectTrigger><SelectValue placeholder="Select a project" /></SelectTrigger>
            <SelectContent>
              {projects.map(p => (
                <SelectItem key={p.id} value={p.id}>{p.project_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input placeholder="Template name" value={templateName} onChange={e => setTemplateName(e.target.value)} />
          <Textarea placeholder="Description (optional)" value={description} onChange={e => setDescription(e.target.value)} />
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button
              onClick={() => createMutation.mutate()}
              disabled={!selectedProjectId || !templateName.trim() || createMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create Template
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}