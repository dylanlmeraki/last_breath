import React, { useState } from "react";
import { portalApi } from "@/components/services/portalApi";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function TemplateProjectPopulator({ open, onOpenChange, template, user, onProjectCreated }) {
  const [projectName, setProjectName] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");

  const createMutation = useMutation({
    mutationFn: async () => {
      const project = await portalApi.entities.Project.create({
        project_name: projectName,
        project_type: template.project_type,
        status: template.default_status || "Planning",
        priority: template.default_priority || "Medium",
        location,
        description,
        client_email: user?.email,
        client_name: user?.full_name,
        progress_percentage: 0,
        budget: template.default_budget || 0,
      });

      // Create milestones from template
      if (template.default_milestones?.length) {
        await Promise.all(
          template.default_milestones.map(m =>
            portalApi.entities.ProjectMilestone.create({
              project_id: project.id,
              milestone_name: m.milestone_name,
              description: m.description || "",
              status: "Pending Client Approval",
              amount: m.amount || 0,
            })
          )
        );
      }

      return project;
    },
    onSuccess: () => {
      toast.success("Project created from template");
      onProjectCreated?.();
      onOpenChange(false);
      setProjectName("");
      setLocation("");
      setDescription("");
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Project from "{template?.template_name}"</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <Input placeholder="Project name" value={projectName} onChange={e => setProjectName(e.target.value)} />
          <Input placeholder="Location" value={location} onChange={e => setLocation(e.target.value)} />
          <Textarea placeholder="Description (optional)" value={description} onChange={e => setDescription(e.target.value)} />
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button
              onClick={() => createMutation.mutate()}
              disabled={!projectName.trim() || createMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create Project
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}