/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import About from './pages/About';
import Auth from './pages/Auth';
import Blog from './pages/Blog';
import ClientAuth from './pages/ClientAuth';
import ClientPortal from './pages/ClientPortal';
import Construction from './pages/Construction';
import Contact from './pages/Contact';
import Home from './pages/Home';
import InspectionsTesting from './pages/InspectionsTesting';
import PortalRegister from './pages/PortalRegister';
import PreviousWork from './pages/PreviousWork';
import ProjectDetail from './pages/ProjectDetail';
import ProjectGallery from './pages/ProjectGallery';
import SWPPPChecker from './pages/SWPPPChecker';
import Services from './pages/Services';
import ServicesOverview from './pages/ServicesOverview';
import SpecialInspections from './pages/SpecialInspections';
import StructuralEngineering from './pages/StructuralEngineering';
import __Layout from './Layout.jsx';


export const PAGES = {
    "About": About,
    "Auth": Auth,
    "Blog": Blog,
    "ClientAuth": ClientAuth,
    "ClientPortal": ClientPortal,
    "Construction": Construction,
    "Contact": Contact,
    "Home": Home,
    "InspectionsTesting": InspectionsTesting,
    "PortalRegister": PortalRegister,
    "PreviousWork": PreviousWork,
    "ProjectDetail": ProjectDetail,
    "ProjectGallery": ProjectGallery,
    "SWPPPChecker": SWPPPChecker,
    "Services": Services,
    "ServicesOverview": ServicesOverview,
    "SpecialInspections": SpecialInspections,
    "StructuralEngineering": StructuralEngineering,
}

export const pagesConfig = {
    mainPage: "ClientPortal",
    Pages: PAGES,
    Layout: __Layout,
};